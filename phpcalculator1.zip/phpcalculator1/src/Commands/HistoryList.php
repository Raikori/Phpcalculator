<?php


namespace Symfony\Component\Console\Command;

use Symfony\Component\Console\Helper\DescriptorHelper;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class History:List extends Command
{
    /**
     * @var string
     */
    protected $signature;

    /**
     * @var string
     */
    protected $description;

    private $command;

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this->ignoreValidationErrors();

        $this
            ->setName('history:List')
            // ->addArgument('base', InputArgument::REQUIRED, 'The base number')
            // ->addArgument('exp',InputArgument::OPTIONAL,'The exponent number')
            ->setDefinition([
                new InputArgument('command', InputArgument::OPTIONAL, 'Filter the history by command'),
            ])
            ->setDescription('Show calculator history');
    }

}
